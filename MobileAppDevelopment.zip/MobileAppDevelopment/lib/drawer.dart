import 'package:flutter/material.dart';

class MyDrawer extends StatelessWidget {
  final Function onTap;
  MyDrawer({this.onTap});
  Widget build(BuildContext context) {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.8,
      child: Drawer(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.blue),
              child: Padding(
                padding: EdgeInsets.all(6),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: <Widget>[],
                ),
              ),
            ),
            /*  ListTile(
                  leading: Icon(Icons.person),
                  title: Text('Profile'),
                  onTap: () => onTap(context, 0, 'Profile'),
                ), */
            ListTile(
              leading: Icon(Icons.accessibility_new),
              title: Text('About'),
              onTap: () => onTap(context, 0, 'About'),
            ),
            ListTile(
              leading: Icon(Icons.food_bank),
              title: Text('Best Food'),
              onTap: () => onTap(context, 1, 'Best food'),
            ),
            ListTile(
              leading: Icon(Icons.map),
              title: Text('Maps'),
              onTap: () => onTap(context, 2, 'Our Locations'),
            ),
            ListTile(
              leading: Icon(Icons.bar_chart),
              title: Text('Sales Chart'),
              onTap: () => onTap(context, 3, 'Chart'),
            ),
            ListTile(
              leading: Icon(Icons.format_align_right_sharp),
              title: Text('View All'),
              onTap: () => onTap(context, 4, 'View All'),
            ),
          ],
        ),
      ),
    );
  }
}
