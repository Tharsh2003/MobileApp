import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
const kactiveCardColor=Colors.deepPurple;  // constant colour give to every Box Layout
const kinactiveCardColor=Color(0xFF1D1E33); // gesture color when on Tap function works
const kbottomContainHeight=60.0;// bottom height fot button pressing at the bottom side
const knumberTextStyle=TextStyle(fontSize: 50.0,fontWeight: FontWeight.w900); // is for number textstyle like height
const klabelTextStyle=TextStyle(fontSize: 18.0,color: Colors.white);

const klargestButtonTextStyle=TextStyle(
  fontSize: 25.0,
  fontWeight: FontWeight.bold,
);
const ktitleTextStyle=TextStyle(fontSize: 50.0,fontWeight: FontWeight.bold);

const kresultTextStyle=TextStyle(color: Color(0xFF24D876),fontSize: 22.0,fontWeight: FontWeight.bold);
//const kLargeButtonTextStyle=TextStyle(fontSize: 22.0,fontWeight: FontWeight.bold);
const kBMITextStyle=TextStyle(fontSize: 100.0,fontWeight: FontWeight.bold);
const kbodyTextStyle=TextStyle(fontSize: 22.0);