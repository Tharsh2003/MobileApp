import 'dart:async';
import 'httpservice2.dart';
import 'package:flutter/material.dart';
import 'Car.dart';
import 'main.dart';

class CarJsonParse2 extends StatefulWidget {
  CarJsonParse2({Key key}) : super(key: key);
  @override
  _CPJsonParseState createState() => _CPJsonParseState();
}

class Debouncer {
  final int msecond;
  VoidCallback action;
  Timer _timer;
  Debouncer({this.msecond});
  run(VoidCallback action) {
    if (null != _timer) {
      _timer.cancel();
    }
    _timer = Timer(Duration(milliseconds: msecond), action);
  }
}

class _CPJsonParseState extends State<CarJsonParse2> {
  final debouncer = Debouncer(msecond: 1000);
  List<Value> _cp2;
  bool _loading;
  @override
  void initState() {
    super.initState();
    _loading = true;
    HttpService2.getCarparks().then((cp2) {
      setState(() {
        _cp2 = cp2;
        _loading = false;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_loading ? 'Loading...' : 'Taxi Availability'),
      ),
      body: Container(
        padding: EdgeInsets.all(8.0),
        child: Column(
          children: [
            searchTF(),
            Padding(
              padding: EdgeInsets.fromLTRB(20, 20, 20, 20),
              child: Container(
                  width: 280,
                  height: 40,
                  color: Colors.white,
                  child: RaisedButton(
                    color: Colors.black,
                    child: Text(
                      'Wish to take another transport to the restaurant?Click Me!',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.white,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    onPressed: () {
                      Navigator.pop(context, true);
                    },
                  )),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: null == _cp2 ? 0 : _cp2.length,
                itemBuilder: (context, index) {
                  Value cpAvail = _cp2[index];
                  return Card(
                    child: Padding(
                      padding: EdgeInsets.all(10.0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            ' Name: ' + cpAvail.name,
                            style: TextStyle(
                                fontSize: 14.0, color: Colors.black87),
                          ),
                          SizedBox(height: 5.0),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Longitude: ' + cpAvail.longitude.toString(),
                                style: TextStyle(
                                    fontSize: 16.0, color: Colors.black),
                              ),
                              Text(
                                'Latitude: ' + cpAvail.latitude.toString(),
                                style: TextStyle(
                                    fontSize: 14.0, color: Colors.black87),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget searchTF() {
    return TextField(
      decoration: InputDecoration(
        border: OutlineInputBorder(
          borderRadius: const BorderRadius.all(
            const Radius.circular(5.0),
          ),
        ),
        filled: true,
        fillColor: Colors.white60,
        contentPadding: EdgeInsets.all(15.0),
        hintText: 'Filter by Area',
      ),
      onChanged: (string) {
        debouncer.run(() {
          HttpService2.getCarparks().then((uCp) {
            setState(() {
              _cp2 = Value.filterList2(uCp, string);
            });
          });
        });
      },
    );
  }
}
