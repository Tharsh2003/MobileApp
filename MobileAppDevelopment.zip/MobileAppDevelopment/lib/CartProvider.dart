import 'package:flutter/material.dart';
import 'ShoeData.dart';

class CartProvider extends ChangeNotifier {
  final _shoeList = [
    Shoe('Fried Rice', '35.0'),
    Shoe('Spring', '16.0'),
    Shoe('Chicken Chop', '30.0'),
    Shoe('Avocado', '18.0'),
    Shoe('Salmon', '32.0'),
    Shoe('Steak', '39.0'),
  ];

  //Map to store cartSize
  Map<int, String> _cartSize = {};

  void setSizeToCart(int index, String sSize) {
    _cartSize[index] = sSize;
    notifyListeners();
    print(_cartSize);
  }

  Map<int, String> get cartSize => _cartSize;

  //Map to store the store name

  Map<int, String> _storeName = {};

  void setNameToCart(int index, String name) {
    _storeName[index] = name;
    notifyListeners();
    print(_storeName);
  }

  Map<int, String> get storeName => _storeName;

  //Map to store the Distance

  Map<int, String> _storeDistance = {};
  void setDistanceToCart(int index, String distance) {
    _storeDistance[index] = distance;
    notifyListeners();
    print(_storeDistance);
  }

  Map<int, String> get storeDistance => _storeDistance;

  //Map to store cart(Qty...etc)

  Map<int, int> _cart = {};
  Map<int, int> get cart => _cart;

  int get cartCount => _cart.length;
  //This is for the total qty

  int get count => _cart.length > 0 ? _cart.values.reduce((a, b) => a + b) : 0;

  void addToCart(int index) {
    if (_cart.containsKey(index)) {
      _cart[index] += 1;
    } else {
      _cart[index] = 1;
    }
    print(_cart);

    notifyListeners();
  }

  void removeFromCart(index) {
    if (_cart.containsKey(index) && _cart[index] >= 1) {
      _cart[index] -= 1;
    } else {
      _cart[index] = 0;
    }
    print(_cart);

    notifyListeners();
  }

  void clear(index) {
    if (_cart.containsKey(index)) {
      _cart.remove(index);

      _cartPrice.remove(index);
      notifyListeners();
    }
  }

  //Map to store cartPrice

  Map<int, double> _cartPrice = {};
  Map<int, double> get cartPrice => _cartPrice;

  double setPriceToCart(int index) {
    double totalPrice = 0.0;
    totalPrice += double.parse(_shoeList[index].shoePrice) * _cart[index];
    totalPrice == 0.0 ? clear(index) : print(totalPrice);

    _cartPrice[index] = totalPrice;
    //this is to sum up all the totals later
    //Will overwrite

    return totalPrice;
  }

  //double get price=> _cartPrice[index]

  double get totalPrice =>
      _cartPrice.length > 0 ? _cartPrice.values.reduce((a, b) => a + b) : 0;
}
