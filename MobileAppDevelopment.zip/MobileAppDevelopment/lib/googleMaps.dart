import 'dart:async';
import 'package:custom_info_window/custom_info_window.dart';
import 'package:flutter/material.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class GoogleMapScreen extends StatefulWidget {
  _GoogleMapScreenState createState() => _GoogleMapScreenState();
}

// Starting point latitude
double _originLatitude = 1.3950044409743703;
// Starting point longitude
double _originLongitude = 103.89467386504073;
// Destination latitude
double _destLatitude = 1.37309519027259;
// Destination Longitude
double _destLongitude = 103.84762286842181;

// Starting point latitude
double _originLatitude2 = 1.375612375384858;
double _originLongitude2 = 103.89364389684258;
// Destination latitude
double _destLatitude2 = 1.3950044409743703;
// Destination Longitude
double _destLongitude2 = 103.89467386504073;

double _originLatitude3 = 1.3730951902725;
double _originLongitude3 = 103.84762286842181;
// Destination latitude
double _destLatitude3 = 1.3698345585027523;
// Destination Longitude
double _destLongitude3 = 103.84762286842181;
// Markers to show points on the map

double _originLatitude4 = 1.3698345585027523;
double _originLongitude4 = 103.84762286842181;
// Destination latitude
double _destLatitude4 = 1.37561237538485;
// Destination Longitude
double _destLongitude4 = 103.89364389684258;
// Markers to show points on the map

Map<MarkerId, Marker> markers = {};

PolylinePoints polylinePoints = PolylinePoints();
Map<PolylineId, Polyline> polylines = {};

class _GoogleMapScreenState extends State<GoogleMapScreen> {
  BitmapDescriptor pinLocationIcon;

  CustomInfoWindowController _customInfoWindowController =
      CustomInfoWindowController();
  Completer<GoogleMapController> _controller = Completer();

  final List<Marker> _markers = <Marker>[];
  final List<LatLng> _LatLng = [
    LatLng(1.3950044409743703, 103.89467386504073),
    LatLng(1.375612375384858, 103.89364389684258),
    LatLng(1.3698345585027523, 103.86564731188943),
    LatLng(1.37309519027259, 103.84762286842181),
  ];

  List<Marker> markers = [];

  void initState() {
    super.initState();
    //setCustomMapPin();
    _getPolyline();
    LoadData();
  }

  BitmapDescriptor customIcon;

/*   void setCustomMapPin() async {
    pinLocationIcon = await BitmapDescriptor.fromAssetImage(
        ImageConfiguration(), 'images/map.png');
  } */

  LoadData() async {
    for (int i = 0; i < _LatLng.length; i++) {
      _markers.add(Marker(
          markerId: MarkerId(
            i.toString(),
          ),
          //icon: BitmapDescriptor.fromAsset("images/map.png"),

          icon: await BitmapDescriptor.fromAssetImage(
              ImageConfiguration(size: Size(48, 48)), 'images/food.png'),
          position: _LatLng[i],
          onTap: () {
            _customInfoWindowController.addInfoWindow(
                Container(
                  height: 300,
                  width: 200,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 300,
                          height: 100,
                          decoration: BoxDecoration(
                            image: DecorationImage(
                              image: AssetImage('images/food${i + 1}.jpg'),
                              fit: BoxFit.fitWidth,
                            ),
                            borderRadius: const BorderRadius.all(
                              Radius.circular(10.0),
                            ),
                            color: Colors.red,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(
                              top: 10, left: 10, right: 10),
                          child: Row(
                            children: [
                              SizedBox(
                                width: 100,
                                child: Text(
                                  'Japanese Food',
                                  maxLines: 1,
                                  overflow: TextOverflow.fade,
                                  softWrap: false,
                                ),
                              ),
                              const Spacer(),
                              Text(
                                '.3 mi.',
                                // widget.data!.date!,
                              )
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(
                              top: 10, left: 10, right: 10),
                          child: Text(
                            'Visit Us at Our Restaurant!' +
                                _LatLng[i].toString(),
                            maxLines: 2,
                          ),
                        ),
                      ]),
                ),
                _LatLng[i]);
          }));

      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          GoogleMap(
            initialCameraPosition: CameraPosition(
                target: LatLng(1.3950044409743703, 103.89467386504073),
                zoom: 15),
            markers: Set<Marker>.of(_markers),
            polylines: Set<Polyline>.of(polylines.values),
            onTap: (position) {
              _customInfoWindowController.hideInfoWindow();
            },
            onCameraMove: (position) {
              _customInfoWindowController.onCameraMove();
            },
            onMapCreated: (GoogleMapController controller) {
              _customInfoWindowController.googleMapController = controller;
            },
          ),
          CustomInfoWindow(
            controller: _customInfoWindowController,
            height: 200,
            width: 300,
            offset: 35,
          )
        ],
      ),
    );
  }

  _addPolyLine(List<LatLng> polylineCoordinates) {
    PolylineId id = PolylineId("poly");
    Polyline polyline = Polyline(
      polylineId: id,
      points: polylineCoordinates,
      width: 8,
      color: Colors.pinkAccent,
    );

    polylines[id] = polyline;
    setState(() {});
  }

  void _getPolyline() async {
    List<LatLng> polylineCoordinates = [];

    PolylineResult result = await polylinePoints.getRouteBetweenCoordinates(
      "AIzaSyBdV7UhyCksC7qRC7Bw-kxlohq737q5m04",
      PointLatLng(_originLatitude, _originLongitude),
      PointLatLng(_destLatitude, _destLongitude),
      travelMode: TravelMode.driving,
    );

    PolylineResult result2 = await polylinePoints.getRouteBetweenCoordinates(
      "AIzaSyBdV7UhyCksC7qRC7Bw-kxlohq737q5m04",
      PointLatLng(_originLatitude2, _originLongitude2),
      PointLatLng(_destLatitude2, _destLongitude2),
      travelMode: TravelMode.driving,
    );

    PolylineResult result3 = await polylinePoints.getRouteBetweenCoordinates(
      "AIzaSyBdV7UhyCksC7qRC7Bw-kxlohq737q5m04",
      PointLatLng(_originLatitude3, _originLongitude3),
      PointLatLng(_destLatitude3, _destLongitude3),
      travelMode: TravelMode.driving,
    );

    PolylineResult result4 = await polylinePoints.getRouteBetweenCoordinates(
      "AIzaSyBdV7UhyCksC7qRC7Bw-kxlohq737q5m04",
      PointLatLng(_originLatitude4, _originLongitude4),
      PointLatLng(_destLatitude4, _destLongitude4),
      travelMode: TravelMode.driving,
    );

    if (result.points.isNotEmpty ||
        result2.points.isNotEmpty ||
        result3.points.isNotEmpty ||
        result4.points.isNotEmpty) {
      result.points.forEach((PointLatLng point) {
        polylineCoordinates.add(LatLng(point.latitude, point.longitude));
      });
      result2.points.forEach((PointLatLng point2) {
        polylineCoordinates.add(LatLng(point2.latitude, point2.longitude));
      });

      result3.points.forEach((PointLatLng point3) {
        polylineCoordinates.add(LatLng(point3.latitude, point3.longitude));
      });

      result4.points.forEach((PointLatLng point4) {
        polylineCoordinates.add(LatLng(point4.latitude, point4.longitude));
      });
    } else {
      print(result.errorMessage);
    }

    _addPolyLine(polylineCoordinates);
  }
}
