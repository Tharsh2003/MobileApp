import 'package:http/http.dart' as http;
import 'Crowd2.dart';

class HttpService4 {
  // static const String url =
  //     'http://datamall2.mytransport.sg/ltaodataservice/BicycleParkingv2?Lat=1.364897&Long=103.766094&Dist=0.5';

  static Future<List<Value>> createBicycle(String station) async {
    try {
      final response = await http.get(
          'http://datamall2.mytransport.sg/ltaodataservice/PCDRealTime?TrainLine=' +
              station,
          headers: {
            'AccountKey': '+Zck4zrtQwiMe2pAAuZ3gg==',
            'accept': 'application/json'
          });

      if (response.statusCode == 200) {
        final Crowd cp = crowdFromJson(response.body);
        return cp.value;
      } else {
        return List<Value>();
      }
    } catch (e) {
      print('Error ${e.toString()}');
      return List<Value>();
    }
  } //getCarparks
}
