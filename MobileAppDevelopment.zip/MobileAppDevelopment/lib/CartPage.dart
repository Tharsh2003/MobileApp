import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'Booking.dart';
import 'CartProvider.dart';
import 'ProductPage.dart';

class CartPage extends StatelessWidget {
  CartPage({Key key}) : super(key: key);

  Widget build(BuildContext context) {
    var cartProvider = Provider.of<CartProvider>(context);
    var cart = cartProvider.cart;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightBlueAccent,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => ProductPage()),
            );
          },
        ),
        title: Text('Your Cart'),
        automaticallyImplyLeading: false,
        /*  actions: <Widget>[
            Center(
              child: Text(
                '   Total :' + cartProvider.totalPrice.toString(),
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 16.0,
                    fontWeight: FontWeight.w500),
              ),
            ),
          ], */
      ),
      body: ListView.builder(
          itemCount: cart.length,
          itemBuilder: (context, index) {
            int cartIndex = cart.keys.toList()[index];

            String sName = cartProvider.storeName[cartIndex] != null
                ? cartProvider.storeName[cartIndex]
                : '';

            String sDistance = cartProvider.storeDistance[cartIndex] != null
                ? cartProvider.storeDistance[cartIndex]
                : '';

            int count = cart[cartIndex];
            //This is for the quantity

            //print(count);
            return Card(
              color: Colors.lightBlue[50],
              elevation: 5,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        height: 100,
                        width: 150,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            image: AssetImage('images/chin${index + 1}.jpg'),
                            fit: BoxFit.fitWidth,
                          ),
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                    Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Seats:$count',
                              style: TextStyle(
                                fontSize: 16.0,
                                fontWeight: FontWeight.w500,
                              )),
                          Text('Name: ' + sName,
                              style: TextStyle(
                                fontSize: 16.0,
                                fontWeight: FontWeight.w500,
                              )),
                          Text('Distance: ' + sDistance,
                              style: TextStyle(
                                fontSize: 16.0,
                                fontWeight: FontWeight.w500,
                              )),
                          Center(
                              child: Container(
                            margin: EdgeInsets.fromLTRB(0, 30, 0, 0),
                            width: 150,
                            height: 20,
                            color: Colors.white,
                            child: RaisedButton(
                              color: Colors.blue,
                              child: Text(
                                'View Booking',
                                style: TextStyle(
                                  fontSize: 16,
                                  color: Colors.white,
                                ),
                              ),
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => BookingPage(
                                          distance: sDistance, seat: count)),
                                );
                              },
                            ),
                          )),
                        ]),
                    IconButton(
                        icon: Icon(Icons.clear),
                        onPressed: () {
                          cartProvider.clear(cartIndex);
                        }),
                  ]),
            );
          }),
    );
  }
}
