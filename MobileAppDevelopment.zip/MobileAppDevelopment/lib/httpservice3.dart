import 'package:http/http.dart' as http;
import 'driver.dart';

class HttpService3 {
  static const String url =
      'http://datamall2.mytransport.sg/ltaodataservice/CarParkAvailabilityv2';

  static Future<List<Value>> getCarparks() async {
    try {
      final response = await http.get(url, headers: {
        'AccountKey': '+Zck4zrtQwiMe2pAAuZ3gg==',
        'accept': 'application/json'
      });

      if (response.statusCode == 200) {
        final Carparks cp = carparksFromJson(response.body);
        return cp.value;
      } else {
        return List<Value>();
      }
    } catch (e) {
      print('Error ${e.toString()}');
      return List<Value>();
    }
  } //getCarparks
}
