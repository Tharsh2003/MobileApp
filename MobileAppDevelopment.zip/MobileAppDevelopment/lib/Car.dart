import 'dart:convert';

Welcome welcomeFromJson(String str) => Welcome.fromJson(json.decode(str));

String welcomeToJson(Welcome data) => json.encode(data.toJson());

class Welcome {
  Welcome({
    this.odataMetadata,
    this.value,
  });

  String odataMetadata;
  List<Value> value;

  factory Welcome.fromJson(Map<String, dynamic> json) => Welcome(
        odataMetadata: json["odata.metadata"],
        value: List<Value>.from(json["value"].map((x) => Value.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "odata.metadata": odataMetadata,
        "value": List<dynamic>.from(value.map((x) => x.toJson())),
      };
}

class Value {
  Value({
    this.taxiCode,
    this.latitude,
    this.longitude,
    this.bfa,
    this.ownership,
    this.type,
    this.name,
  });

  String taxiCode;
  double latitude;
  double longitude;
  Bfa bfa;
  Ownership ownership;
  Type type;
  String name;

  factory Value.fromJson(Map<String, dynamic> json) => Value(
        taxiCode: json["TaxiCode"],
        latitude: json["Latitude"].toDouble(),
        longitude: json["Longitude"].toDouble(),
        bfa: bfaValues.map[json["Bfa"]],
        ownership: ownershipValues.map[json["Ownership"]],
        type: typeValues.map[json["Type"]],
        name: json["Name"],
      );

  Map<String, dynamic> toJson() => {
        "TaxiCode": taxiCode,
        "Latitude": latitude,
        "Longitude": longitude,
        "Bfa": bfaValues.reverse[bfa],
        "Ownership": ownershipValues.reverse[ownership],
        "Type": typeValues.reverse[type],
        "Name": name,
      };

  static List<Value> filterList2(List<Value> vl, String filterString) {
    List<Value> _v = vl
        .where((u) => (u.name
            .toString()
            .toLowerCase()
            .contains(filterString.toLowerCase())))
        .toList();
    return _v;
  }
}

enum Bfa { YES, NO }

final bfaValues = EnumValues({"No": Bfa.NO, "Yes": Bfa.YES});

enum Ownership { LTA, PRIVATE, CCS, SMRT }

final ownershipValues = EnumValues({
  "CCS": Ownership.CCS,
  "LTA": Ownership.LTA,
  "Private": Ownership.PRIVATE,
  "SMRT": Ownership.SMRT
});

enum Type { STAND, STOP }

final typeValues = EnumValues({"Stand": Type.STAND, "Stop": Type.STOP});

class EnumValues<T> {
  Map<String, T> map;
  Map<T, String> reverseMap;

  EnumValues(this.map);

  Map<T, String> get reverse {
    if (reverseMap == null) {
      reverseMap = map.map((k, v) => new MapEntry(v, k));
    }
    return reverseMap;
  }
}
