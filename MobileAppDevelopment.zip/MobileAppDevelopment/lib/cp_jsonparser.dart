import 'dart:async';
import 'package:flutter/material.dart';
import 'httpservice.dart';
import 'Carparks.dart';

class CPJsonParse extends StatefulWidget {
  CPJsonParse({Key key}) : super(key: key);
  @override
  _CPJsonParseState createState() => _CPJsonParseState();
}

class Debouncer {
  final int msecond;
  VoidCallback action;
  Timer _timer;
  Debouncer({this.msecond});
  run(VoidCallback action) {
    if (null != _timer) {
      _timer.cancel();
    }
    _timer = Timer(Duration(milliseconds: msecond), action);
  }
}

String Level;

class _CPJsonParseState extends State<CPJsonParse> {
  // List<Value> _user;

  final TextEditingController latController = TextEditingController();
  final TextEditingController longController = TextEditingController();

  final debouncer = Debouncer(msecond: 1000);

  List<Value> _cp;
  bool _loading;
  @override
  void initState() {
    super.initState();
    _loading = true;
    HttpService.createBicycle(latController.text, longController.text)
        .then((cp) {
      setState(() {
        _cp = cp;
        _loading = false;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_loading ? 'MRT Train Services' : 'Bicycle Parking'),
      ),
      body: Container(
        padding: EdgeInsets.all(8.0),
        child: Column(
          children: [
            Container(
              height: 70.0,
              width: 70.0,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('images/bicycle.jpg'),
                  fit: BoxFit.fill,
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.fromLTRB(20, 20, 20, 20),
              child: Container(
                  width: 280,
                  height: 40,
                  color: Colors.white,
                  child: RaisedButton(
                    color: Colors.black,
                    child: Text(
                      'Wish to take another transport to the restaurant?Click Me!',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.white,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    onPressed: () {
                      Navigator.pop(context, true);
                    },
                  )),
            ),
            Container(
              padding: EdgeInsets.all(32),
              child: Column(
                children: <Widget>[
                  Text(
                    '\nLATITUDE',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 28,
                      color: Colors.red,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Lora',
                    ),
                  ),
                  TextField(
                    controller: latController,
                  ),
                  Text(
                    '\nLONGTITUDE',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 28,
                      color: Colors.red,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Lora',
                    ),
                  ),
                  TextField(
                    controller: longController,
                  ),
                  ElevatedButton(
                    onPressed: () async {
                      final String lat = latController.text;
                      final String long = longController.text;

                      final List<Value> stationName =
                          await HttpService.createBicycle(lat, long);

                      setState(() {
                        //_user = user;
                        debouncer.run(() {
                          HttpService.createBicycle(lat, long).then((uCp) {
                            setState(() {
                              _cp = stationName;
                            });
                          });
                        });
                      });
                    },
                    child: Text("Next"),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: null == _cp ? 0 : _cp.length,
                itemBuilder: (context, index) {
                  Value cpAvail = _cp[index];

                  return Card(
                      child: Padding(
                    padding: EdgeInsets.all(10.0),
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Description: ' + cpAvail.description,
                                style: TextStyle(
                                    fontSize: 16.0, color: Colors.black),
                              ),
                              SizedBox(height: 5.0),
                              Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    'Latitude: ' + cpAvail.latitude.toString(),
                                    style: TextStyle(
                                        fontSize: 14.0, color: Colors.black87),
                                  ),
                                  Text(
                                    'Longitude: ' +
                                        cpAvail.longitude.toString(),
                                    style: TextStyle(
                                        fontSize: 14.0, color: Colors.black87),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          Icon(Icons.directions, size: 50, color: Colors.red)
                        ]),
                  ));
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
