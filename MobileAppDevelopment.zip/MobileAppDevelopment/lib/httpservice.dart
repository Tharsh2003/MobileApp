import 'package:http/http.dart' as http;
import 'Carparks.dart';

class HttpService {
  static Future<List<Value>> createBicycle(String latitude, String long) async {
    try {
      final response = await http.get(
          'http://datamall2.mytransport.sg/ltaodataservice/BicycleParkingv2?Lat=' +
              latitude +
              '&Long=' +
              long +
              '&Dist= 0.5',
          headers: {
            'AccountKey': '+Zck4zrtQwiMe2pAAuZ3gg==',
            'accept': 'application/json'
          });

      if (response.statusCode == 200) {
        final Welcome cp = welcomeFromJson(response.body);
        return cp.value;
      } else {
        return List<Value>();
      }
    } catch (e) {
      print('Error ${e.toString()}');
      return List<Value>();
    }
  } //getCarparks
}
