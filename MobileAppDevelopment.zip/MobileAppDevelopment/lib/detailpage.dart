import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'CartPage.dart';
import 'Crowd.dart';
import 'CartProvider.dart';

void main() {
  runApp(DetailPage());
}

class Detail extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: DetailPage(),
      ),
    );
  }
}

class DetailPage extends StatefulWidget {
  const DetailPage(
      {Key key,
      this.index,
      this.shoeName,
      this.image,
      this.price,
      this.description,
      this.rating,
      this.review,
      this.distance})
      : super(key: key);
  final int index;
  final String shoeName;
  final String image;
  final String price;
  final String description;
  final String rating;
  final String review;
  final String distance;

  _DetailPageState createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  String selectedValue;
  //Always claim when there is dropdown menu

  int _itemCount = 0;

  Widget build(BuildContext context) {
    //var cartProvider = Provider.of<CartProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('Detail Page'),
        backgroundColor: Colors.lightBlueAccent,
        actions: <Widget>[
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Container(
              height: 150.0,
              width: 30.0,
              child: InkWell(
                  splashColor: Colors.redAccent,
                  highlightColor: Colors.blueAccent.withOpacity(0.5),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => CartPage(),
                      ),
                    );
                  },
                  child: Stack(children: <Widget>[
                    Positioned(
                        child: Stack(
                      children: <Widget>[],
                    )),
                  ])),
            ),
          ),
        ],
      ),
      body: Container(
        child: Column(
          //mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.max,
          children: <Widget>[
            Container(
              width: 380,
              height: 150,
              margin: const EdgeInsets.fromLTRB(0, 5, 0, 10),
              decoration: BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage(widget.image), fit: BoxFit.cover),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: Colors.black,
                    width: 3,
                  )),
              child: Center(
                child: Container(
                  width: 250,
                  height: 140,
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: Colors.black,
                        width: 3,
                      )),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: <Widget>[
                      Center(
                        child: Padding(
                          padding: EdgeInsets.all(5),
                          child: Text(
                            widget.shoeName,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              height: 1.5,
                              fontWeight: FontWeight.bold,
                              color: Colors.black,
                              decoration: TextDecoration.none,
                              fontSize: 10,
                              fontFamily: 'Lora',
                            ),
                          ),
                        ),
                      ),
                      Center(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: const <Widget>[
                            Icon(
                              Icons.star,
                              size: 15.0,
                              color: Colors.yellow,
                            ),
                            Icon(
                              Icons.star,
                              size: 15.0,
                              color: Colors.yellow,
                            ),
                            Icon(
                              Icons.star,
                              size: 15.0,
                              color: Colors.yellow,
                            ),
                            Icon(
                              Icons.star,
                              size: 15.0,
                              color: Colors.yellow,
                            ),
                            Icon(
                              Icons.star,
                              size: 15.0,
                              color: Colors.yellow,
                            ),
                          ],
                        ),
                      ),
                      Center(
                          child: Container(
                        margin: EdgeInsets.fromLTRB(0, 30, 0, 10),
                        width: 170,
                        height: 30,
                        color: Colors.white,
                        child: RaisedButton(
                          color: Colors.lightBlueAccent,
                          child: Text(
                            'View Crowd',
                            style: TextStyle(
                              fontSize: 10,
                              color: Colors.white,
                            ),
                          ),
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => CrowdPage(
                                        index: widget.index,
                                        shoeName: widget.shoeName,
                                        distance: widget.distance,
                                      )),
                            );
                          },
                        ),
                      )),
                    ],
                  ),
                ),
              ),
            ),
            Container(
                child: Center(
              child: Padding(
                padding: EdgeInsets.all(5),
                child: Text(
                  widget.description,
                  style: TextStyle(
                    height: 1.5,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                    decoration: TextDecoration.none,
                    fontSize: 14,
                    fontFamily: 'Lora',
                  ),
                ),
              ),
            )),
            Align(
              alignment: Alignment.centerLeft,
              child: Container(
                  child: Padding(
                padding: EdgeInsets.all(5),
                child: Text(
                  "Distance \n" + widget.distance,
                  textAlign: TextAlign.left,
                  style: TextStyle(
                    height: 1.5,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                    decoration: TextDecoration.none,
                    fontSize: 15,
                    fontFamily: 'Lora',
                  ),
                ),
              )),
            ),
            Align(
              alignment: Alignment.centerLeft,
              child: Container(
                  child: Padding(
                padding: EdgeInsets.all(5),
                child: Text(
                  'Reviews & Ratings',
                  textAlign: TextAlign.left,
                  style: TextStyle(
                    height: 1.5,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                    decoration: TextDecoration.none,
                    fontSize: 14,
                    fontFamily: 'Lora',
                  ),
                ),
              )),
            ),
            Container(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Center(
                    child: Container(
                      margin: EdgeInsets.fromLTRB(0, 5, 0, 5),
                      width: 70,
                      height: 70,
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage('images/girl.jpg'),
                        ),
                        shape: BoxShape.circle,
                      ),
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    //mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Align(
                        alignment: Alignment.topLeft,
                        child: Container(
                          child: Text(
                            'Average',
                            textAlign: TextAlign.left,
                            style: TextStyle(
                              height: 1.5,
                              fontWeight: FontWeight.bold,
                              color: Colors.black,
                              decoration: TextDecoration.none,
                              fontSize: 10,
                              fontFamily: 'Lora',
                            ),
                          ),
                        ),
                      ),
                      Text(
                        'An amazing place to hang out with Friends and Family',
                        style: TextStyle(
                          height: 1.5,
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                          decoration: TextDecoration.none,
                          fontSize: 10,
                          fontFamily: 'Lora',
                        ),
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: const <Widget>[
                      Icon(
                        Icons.star,
                        size: 15.0,
                        color: Colors.yellow,
                      ),
                      Icon(
                        Icons.star,
                        size: 15.0,
                        color: Colors.yellow,
                      ),
                      Icon(
                        Icons.star,
                        size: 15.0,
                        color: Colors.yellow,
                      ),
                      Icon(
                        Icons.star,
                        size: 15.0,
                        color: Colors.yellow,
                      ),
                      Icon(
                        Icons.star,
                        size: 15.0,
                        color: Colors.yellow,
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Container(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: <Widget>[
                  Center(
                    child: Container(
                      margin: EdgeInsets.fromLTRB(0, 5, 0, 5),
                      width: 70,
                      height: 70,
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage('images/girl.jpg'),
                        ),
                        shape: BoxShape.circle,
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          'Average',
                          textAlign: TextAlign.left,
                          style: TextStyle(
                            height: 1.5,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                            decoration: TextDecoration.none,
                            fontSize: 10,
                            fontFamily: 'Lora',
                          ),
                        ),
                        Text(
                          'An amazing place to hang out with Friends and Family',
                          style: TextStyle(
                            height: 1.5,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                            decoration: TextDecoration.none,
                            fontSize: 10,
                            fontFamily: 'Lora',
                          ),
                        ),
                      ],
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: const <Widget>[
                      Icon(
                        Icons.star,
                        size: 15.0,
                        color: Colors.yellow,
                      ),
                      Icon(
                        Icons.star,
                        size: 15.0,
                        color: Colors.yellow,
                      ),
                      Icon(
                        Icons.star,
                        size: 15.0,
                        color: Colors.yellow,
                      ),
                      Icon(
                        Icons.star,
                        size: 15.0,
                        color: Colors.yellow,
                      ),
                      Icon(
                        Icons.star,
                        size: 15.0,
                        color: Colors.yellow,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
