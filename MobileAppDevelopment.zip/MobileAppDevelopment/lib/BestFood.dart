import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'RateUs.dart';

class BestFood extends StatefulWidget {
  const BestFood({Key key}) : super(key: key);

  @override
  _RatingPageState createState() => _RatingPageState();
}

class _RatingPageState extends State<BestFood> {
  double _ratingValue;
  double _ratingValue2;
  double _ratingValue3;
  double _ratingValue4;
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        mainAxisSize: MainAxisSize.max,
        children: <Widget>[
          Container(
            width: 250,
            height: 40,
            margin: const EdgeInsets.fromLTRB(0, 10, 0, 0),
            decoration: BoxDecoration(
              //borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: Colors.black,
                width: 3,
              ),
              color: Colors.red,
            ),
            child: const Center(
              child: Text(
                'Best Food',
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 25,
                    color: Colors.white),
              ),
            ),
          ),
          Container(
            width: 150,
            height: 50,
            margin: const EdgeInsets.fromLTRB(0, 10, 0, 5),
            child: const Center(
              child: Text(
                'Popular',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 21,
                  color: Colors.red,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Lora',
                ),
              ),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: <Widget>[
              Container(
                margin: EdgeInsets.fromLTRB(0, 40, 0, 30),
                child: Column(
                  children: [
                    Container(
                      margin: const EdgeInsets.fromLTRB(0, 0, 5, 5),
                      width: 190,
                      height: 170,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: Colors.black,
                          width: 3,
                        ),
                        image: DecorationImage(
                          image: AssetImage('images/chin1.jpg'),
                          fit: BoxFit.cover,
                        ),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: <Widget>[
                          //color: Colors.white,
                          Padding(
                            padding: const EdgeInsets.all(5),
                            child: Center(
                              child: Column(
                                children: [
                                  Container(
                                    width: 150,
                                    height: 30,
                                    color: Colors.white,
                                    child: Align(
                                      alignment: Alignment.center,
                                      child: Text(
                                        'Iciban',
                                        style: TextStyle(
                                            fontSize: 14,
                                            color: Colors.red,
                                            fontWeight: FontWeight.bold),
                                        textAlign: TextAlign.center,
                                      ),
                                    ),
                                  ),

                                  //const SizedBox(height: 10),
                                  // implement the rating bar
                                  RatingBar(
                                      initialRating: 0,
                                      direction: Axis.horizontal,
                                      allowHalfRating: true,
                                      itemCount: 4,
                                      ratingWidget: RatingWidget(
                                          full: const Icon(Icons.star,
                                              color: Colors.yellow),
                                          half: const Icon(
                                            Icons.star_half,
                                            color: Colors.yellow,
                                          ),
                                          empty: const Icon(
                                            Icons.star_outline,
                                            color: Colors.yellow,
                                          )),
                                      onRatingUpdate: (value) {
                                        setState(() {
                                          _ratingValue = value;
                                        });
                                      }),
                                  const SizedBox(height: 10),
                                  // Display the rate in number
                                  Container(
                                    width: 60,
                                    height: 60,
                                    decoration: const BoxDecoration(
                                      color: Colors.orange,
                                      shape: BoxShape.circle,
                                      image: const DecorationImage(
                                        image: AssetImage('images/heart.jpg'),
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                    alignment: Alignment.center,
                                    child: Text(
                                      _ratingValue != null
                                          ? _ratingValue.toString()
                                          : 'Rate!',
                                      style: const TextStyle(
                                          color: Colors.white, fontSize: 18),
                                    ),
                                  )
                                ],
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                child: Column(
                  children: [
                    Container(
                      margin: const EdgeInsets.fromLTRB(0, 0, 5, 5),
                      width: 190,
                      height: 170,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: Colors.black,
                          width: 3,
                        ),
                        image: DecorationImage(
                          image: AssetImage('images/chin2.jpg'),
                          fit: BoxFit.cover,
                        ),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: <Widget>[
                          //color: Colors.white,
                          Padding(
                            padding: const EdgeInsets.all(5),
                            child: Center(
                              child: Column(
                                children: [
                                  Container(
                                    width: 150,
                                    height: 30,
                                    color: Colors.white,
                                    child: Align(
                                      alignment: Alignment.center,
                                      child: Text(
                                        'Genki',
                                        style: TextStyle(
                                            fontSize: 14,
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold),
                                        textAlign: TextAlign.center,
                                      ),
                                    ),
                                  ),

                                  //const SizedBox(height: 10),
                                  // implement the rating bar
                                  RatingBar(
                                      initialRating: 0,
                                      direction: Axis.horizontal,
                                      allowHalfRating: true,
                                      itemCount: 4,
                                      ratingWidget: RatingWidget(
                                          full: const Icon(Icons.star,
                                              color: Colors.yellow),
                                          half: const Icon(
                                            Icons.star_half,
                                            color: Colors.yellow,
                                          ),
                                          empty: const Icon(
                                            Icons.star_outline,
                                            color: Colors.yellow,
                                          )),
                                      onRatingUpdate: (value) {
                                        setState(() {
                                          _ratingValue2 = value;
                                        });
                                      }),
                                  const SizedBox(height: 10),
                                  // Display the rate in number
                                  Container(
                                    width: 60,
                                    height: 60,
                                    decoration: const BoxDecoration(
                                      color: Colors.black,
                                      shape: BoxShape.circle,
                                      image: const DecorationImage(
                                        image: AssetImage('images/heart.jpg'),
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                    alignment: Alignment.center,
                                    child: Text(
                                      _ratingValue2 != null
                                          ? _ratingValue2.toString()
                                          : 'Rate!',
                                      style: const TextStyle(
                                          color: Colors.white, fontSize: 18),
                                    ),
                                  )
                                ],
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: <Widget>[
              Container(
                child: Column(
                  children: [
                    Container(
                      margin: const EdgeInsets.fromLTRB(0, 0, 5, 5),
                      width: 190,
                      height: 170,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: Colors.black,
                          width: 3,
                        ),
                        image: DecorationImage(
                          image: AssetImage('images/chin3.jpg'),
                          fit: BoxFit.cover,
                        ),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: <Widget>[
                          //color: Colors.white,
                          Padding(
                            padding: const EdgeInsets.all(5),
                            child: Center(
                              child: Column(
                                children: [
                                  Container(
                                    width: 150,
                                    height: 30,
                                    color: Colors.white,
                                    child: Align(
                                      alignment: Alignment.center,
                                      child: Text(
                                        'Ajsen',
                                        style: TextStyle(
                                            fontSize: 14,
                                            color: Colors.purple,
                                            fontWeight: FontWeight.bold),
                                        textAlign: TextAlign.center,
                                      ),
                                    ),
                                  ),

                                  //const SizedBox(height: 10),
                                  // implement the rating bar
                                  RatingBar(
                                      initialRating: 0,
                                      direction: Axis.horizontal,
                                      allowHalfRating: true,
                                      itemCount: 4,
                                      ratingWidget: RatingWidget(
                                          full: const Icon(Icons.star,
                                              color: Colors.yellow),
                                          half: const Icon(
                                            Icons.star_half,
                                            color: Colors.yellow,
                                          ),
                                          empty: const Icon(
                                            Icons.star_outline,
                                            color: Colors.yellow,
                                          )),
                                      onRatingUpdate: (value) {
                                        setState(() {
                                          _ratingValue3 = value;
                                        });
                                      }),
                                  const SizedBox(height: 10),
                                  // Display the rate in number
                                  Container(
                                    width: 60,
                                    height: 60,
                                    decoration: const BoxDecoration(
                                      color: Colors.purple,
                                      shape: BoxShape.circle,
                                      image: const DecorationImage(
                                        image: AssetImage('images/heart.jpg'),
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                    alignment: Alignment.center,
                                    child: Text(
                                      _ratingValue3 != null
                                          ? _ratingValue3.toString()
                                          : 'Rate!',
                                      style: const TextStyle(
                                          color: Colors.white, fontSize: 18),
                                    ),
                                  )
                                ],
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                child: Column(
                  children: [
                    Container(
                      margin: const EdgeInsets.fromLTRB(0, 0, 5, 5),
                      width: 190,
                      height: 170,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: Colors.black,
                          width: 3,
                        ),
                        image: DecorationImage(
                          image: AssetImage('images/chin4.jpg'),
                          fit: BoxFit.cover,
                        ),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: <Widget>[
                          //color: Colors.white,
                          Padding(
                            padding: const EdgeInsets.all(5),
                            child: Center(
                              child: Column(
                                children: [
                                  Container(
                                    width: 150,
                                    height: 30,
                                    color: Colors.white,
                                    child: Align(
                                      alignment: Alignment.center,
                                      child: Text(
                                        'Sushi Tei',
                                        style: TextStyle(
                                            fontSize: 14,
                                            color: Colors.lightBlue,
                                            fontWeight: FontWeight.bold),
                                        textAlign: TextAlign.center,
                                      ),
                                    ),
                                  ),

                                  //const SizedBox(height: 10),
                                  // implement the rating bar
                                  RatingBar(
                                      initialRating: 0,
                                      direction: Axis.horizontal,
                                      allowHalfRating: true,
                                      itemCount: 4,
                                      ratingWidget: RatingWidget(
                                          full: const Icon(Icons.star,
                                              color: Colors.yellow),
                                          half: const Icon(
                                            Icons.star_half,
                                            color: Colors.yellow,
                                          ),
                                          empty: const Icon(
                                            Icons.star_outline,
                                            color: Colors.yellow,
                                          )),
                                      onRatingUpdate: (value) {
                                        setState(() {
                                          _ratingValue4 = value;
                                        });
                                      }),
                                  const SizedBox(height: 10),
                                  // Display the rate in number
                                  Container(
                                    width: 60,
                                    height: 60,
                                    decoration: const BoxDecoration(
                                      color: Colors.lightBlue,
                                      shape: BoxShape.circle,
                                      image: const DecorationImage(
                                        image: AssetImage('images/heart.jpg'),
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                    alignment: Alignment.center,
                                    child: Text(
                                      _ratingValue4 != null
                                          ? _ratingValue4.toString()
                                          : 'Rate!',
                                      style: const TextStyle(
                                          color: Colors.white, fontSize: 18),
                                    ),
                                  )
                                ],
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
