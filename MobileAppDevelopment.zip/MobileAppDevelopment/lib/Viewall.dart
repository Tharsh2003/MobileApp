import 'package:flutter/material.dart';
import 'FirstScreen.dart';
import 'SecondScreen.dart';
import 'ThirdScreen.dart';

void main() {
  runApp(Viewall());
}

class Viewall extends StatelessWidget {
  @override
  final List<Tab> myTabs = <Tab>[
    Tab(text: 'Chinese'),
    Tab(text: 'Japenese'),
    Tab(text: 'Korean'),
  ];

  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: DefaultTabController(
        length: 3,
        child: Scaffold(
          appBar: AppBar(
            title: Text("All Cuisines"),
            backgroundColor: Colors.lightBlueAccent,
            bottom: TabBar(
              tabs: myTabs,
            ),
          ),
          body: TabBarView(
            children: [
              FirstScreen(),
              SecondScreen(),
              ThirdScreen(),
            ],
          ),
        ),
      ),
    );
  }
}
