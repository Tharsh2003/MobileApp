import 'package:flutter/material.dart';

import 'detailpage.dart';

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: Text('Personal Dashboard'),
        ),
        body: FirstScreen(),
      ),
    );
  }
}

class FirstScreen extends StatefulWidget {
  @override
  _FirstState createState() => _FirstState();
}

class _FirstState extends State<FirstScreen> {
  final _shoeName = [
    'Iciban',
    'Ajsen Ramen',
    'Suparakki Ramen',
    'Jap Grill',
  ];

  final _shoePrice = [
    '35.0',
    '16.0',
    '30.0',
    '18.0',
  ];

  final _description = [
    'Ichiban specializes in premier Japanese cuisine without the hefty price tag. Dine at the sushi bar for the full experience.',
    'Famous for its rich Tonkotsu soup (pork broth) which captures the essence after hours of boiling, Ajisen offers a wide variety of ramen which caters to customers of all ages.',
    'Suparakki aims to create a ramen culture with an affordable price that would satisfy cravings and we will continue to strive for the better.',
    'At jap Grill we ensure that we serve meat of the finest quality',
  ];

  final _rating = ['3', '5', '4', '5'];

  final _review = ['34', '53', '46', '58'];

  final _distance = ['34km', '53km', '46km', '58km'];
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
            body: GridView.count(
                crossAxisCount: 2,
                //mainAxisCount:2,
                children: List.generate(
                    4,
                    (index) => Container(
                            child: Column(
                                mainAxisSize: MainAxisSize.max,
                                children: <Widget>[
                              Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceAround,
                                  children: <Widget>[
                                    Container(
                                        child: Column(children: [
                                      Container(
                                        margin: const EdgeInsets.fromLTRB(
                                            0, 0, 5, 5),
                                        width: 170,
                                        height: 140,
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          border: Border.all(
                                            color: Colors.black,
                                            width: 3,
                                          ),
                                          image: DecorationImage(
                                            image: AssetImage(
                                                'images/chin${index + 1}.jpg'),
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                        child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceAround,
                                            children: <Widget>[
                                              //color: Colors.white,
                                              Center(
                                                  child: Container(
                                                width: 80,
                                                height: 20,
                                                color: Colors.white,
                                                child: RaisedButton(
                                                  color: Colors.blue,
                                                  child: Text(
                                                    'More',
                                                    style: TextStyle(
                                                      fontSize: 16,
                                                      color: Colors.white,
                                                    ),
                                                  ),
                                                  onPressed: () {
                                                    Navigator.push(
                                                        context,
                                                        MaterialPageRoute(
                                                          builder: (context) =>
                                                              DetailPage(
                                                            index: index,
                                                            shoeName: _shoeName[
                                                                index],
                                                            image:
                                                                'images/chin${index + 1}.jpg',
                                                            description:
                                                                _description[
                                                                    index],
                                                            rating:
                                                                _rating[index],
                                                            review:
                                                                _review[index],
                                                            distance: _distance[
                                                                index],
                                                            price: (_shoePrice[
                                                                index]),
                                                          ),
                                                        ));
                                                  },
                                                ),
                                              )),
                                            ]),
                                      ),
                                    ]))
                                  ])
                            ]))))));
  }
}
