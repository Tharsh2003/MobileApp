// To parse this JSON data, do
//
//     final crowd = crowdFromJson(jsonString);

import 'dart:convert';

Crowd crowdFromJson(String str) => Crowd.fromJson(json.decode(str));

String crowdToJson(Crowd data) => json.encode(data.toJson());

class Crowd {
  Crowd({
    this.odataMetadata,
    this.value,
  });

  String odataMetadata;
  List<Value> value;

  factory Crowd.fromJson(Map<String, dynamic> json) => Crowd(
        odataMetadata: json["odata.metadata"],
        value: List<Value>.from(json["value"].map((x) => Value.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "odata.metadata": odataMetadata,
        "value": List<dynamic>.from(value.map((x) => x.toJson())),
      };
}

class Value {
  Value({
    this.station,
    this.startTime,
    this.endTime,
    this.crowdLevel,
  });

  String station;
  DateTime startTime;
  DateTime endTime;
  CrowdLevel crowdLevel;

  factory Value.fromJson(Map<String, dynamic> json) => Value(
        station: json["Station"],
        startTime: DateTime.parse(json["StartTime"]),
        endTime: DateTime.parse(json["EndTime"]),
        crowdLevel: crowdLevelValues.map[json["CrowdLevel"]],
      );

  Map<String, dynamic> toJson() => {
        "Station": station,
        "StartTime": startTime.toIso8601String(),
        "EndTime": endTime.toIso8601String(),
        "CrowdLevel": crowdLevelValues.reverse[crowdLevel],
      };
}

enum CrowdLevel { L, NA, M }

final crowdLevelValues =
    EnumValues({"l": CrowdLevel.L, "m": CrowdLevel.M, "na": CrowdLevel.NA});

class EnumValues<T> {
  Map<String, T> map;
  Map<T, String> reverseMap;

  EnumValues(this.map);

  Map<T, String> get reverse {
    if (reverseMap == null) {
      reverseMap = map.map((k, v) => new MapEntry(v, k));
    }
    return reverseMap;
  }
}
