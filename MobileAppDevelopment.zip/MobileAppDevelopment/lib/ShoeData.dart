class Shoe {
  String shoeName;
  String shoePrice;

  Shoe(this.shoeName, this.shoePrice);
}
