import 'package:flutter/material.dart';
import 'driver_jsonparser.dart';
import 'cp_jsonparser.dart';
import 'car_jsonparser.dart';
import 'crowd_jsonparser.dart';

class Bicycle extends StatelessWidget {
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Transport to Restaurant"),
          backgroundColor: Colors.lightBlueAccent,
        ),
        body: Center(
            child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: <Widget>[
              Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: <Widget>[
                    Padding(
                        padding: EdgeInsets.fromLTRB(20, 20, 20, 20),
                        child: Column(children: <Widget>[
                          Container(
                            margin: const EdgeInsets.fromLTRB(0, 0, 5, 5),
                            width: 150,
                            height: 140,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                color: Colors.black,
                                width: 3,
                              ),
                              image: DecorationImage(
                                image: AssetImage('images/bicycle.jpg'),
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          Container(
                              width: 100,
                              height: 40,
                              color: Colors.white,
                              child: RaisedButton(
                                color: Colors.black,
                                child: Text(
                                  'Bicycle',
                                  style: TextStyle(
                                    fontSize: 16,
                                    color: Colors.white,
                                  ),
                                ),
                                onPressed: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => CPJsonParse()),
                                  );
                                },
                              )),
                        ])),
                    Padding(
                      padding: EdgeInsets.fromLTRB(20, 20, 20, 20),
                      child: Column(
                        children: <Widget>[
                          Container(
                            margin: const EdgeInsets.fromLTRB(0, 0, 5, 5),
                            width: 150,
                            height: 140,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                color: Colors.black,
                                width: 3,
                              ),
                              image: DecorationImage(
                                image: AssetImage('images/Taxi.jpg'),
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          Container(
                              width: 100,
                              height: 40,
                              color: Colors.white,
                              child: RaisedButton(
                                color: Colors.blue,
                                child: Text(
                                  'Taxi',
                                  style: TextStyle(
                                    fontSize: 16,
                                    color: Colors.white,
                                  ),
                                ),
                                onPressed: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => CarJsonParse2()),
                                  );
                                },
                              ))
                        ],
                      ),
                    ),
                  ]),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.fromLTRB(20, 20, 20, 20),
                    child: Column(children: <Widget>[
                      Container(
                        margin: const EdgeInsets.fromLTRB(0, 0, 5, 5),
                        width: 150,
                        height: 140,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            color: Colors.black,
                            width: 3,
                          ),
                          image: DecorationImage(
                            image: AssetImage('images/Car.jpg'),
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      Container(
                          width: 100,
                          height: 40,
                          color: Colors.white,
                          child: RaisedButton(
                            color: Colors.black,
                            child: Text(
                              'Car',
                              style: TextStyle(
                                fontSize: 16,
                                color: Colors.white,
                              ),
                            ),
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => CPJsonParse3()),
                              );
                            },
                          )),
                    ]),
                  ),
                  Padding(
                      padding: EdgeInsets.fromLTRB(20, 20, 20, 20),
                      child: Column(children: <Widget>[
                        Container(
                          margin: const EdgeInsets.fromLTRB(0, 0, 5, 5),
                          width: 150,
                          height: 140,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: Colors.black,
                              width: 3,
                            ),
                            image: DecorationImage(
                              image: AssetImage('images/mrt_logo.jpg'),
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                        Container(
                            width: 100,
                            height: 40,
                            color: Colors.white,
                            child: RaisedButton(
                              color: Colors.red,
                              child: Text(
                                'Mrt',
                                style: TextStyle(
                                  fontSize: 16,
                                  color: Colors.white,
                                ),
                              ),
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => CPJsonParse4()),
                                );
                              },
                            )),
                      ]))
                ],
              ),
            ])));
  }
}
