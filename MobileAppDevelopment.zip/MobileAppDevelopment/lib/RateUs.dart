import 'package:flutter/material.dart';
import 'widgets/rating.dart';

void main() {
  runApp(App());
}

class App extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(title: "Flutter Rating Control", home: RatingsPage());
  }
}

class RatingsPage extends StatefulWidget {
  @override
  _RatingsPage createState() => _RatingsPage();
}

enum Answers { YES, NO, MAYBE }

class _RatingsPage extends State<RatingsPage> {
  int _rating;
  String _value = '';
  void _setValue(String value) => setState(() => _value = value);

  Future<void> _askUser() async {
    switch (await showDialog(
      context: context,
      builder: (context) {
        return SimpleDialog(
            title: Text('Do you like our restaurant?'),
            children: <Widget>[
              SimpleDialogOption(
                child: Text(
                  'Excellent Service',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Lora',
                  ),
                ),
                onPressed: () {
                  Navigator.pop(context, Answers.YES);
                },
              ),
              SimpleDialogOption(
                  child: Text(
                    'Poor Service',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Lora',
                    ),
                  ),
                  onPressed: () {
                    Navigator.pop(context, Answers.NO);
                  }),
              SimpleDialogOption(
                child: Text(
                  'Average Service',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Lora',
                  ),
                ),
                onPressed: () {
                  Navigator.pop(context, Answers.MAYBE);
                },
              ),
            ]);
      },
    )) {
      case Answers.YES:
        _setValue('Excellent Service');
        break;

      case Answers.NO:
        _setValue('Poor Service');
        break;

      case Answers.MAYBE:
        _setValue('Average Service');
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Center(
            child: Container(
      height: 603,
      width: 600.0,
      color: Colors.blueGrey,
      child: Container(
        width: 300,
        height: 350,
        decoration: BoxDecoration(
          image: DecorationImage(
              image: AssetImage("images/Register.jpg"), fit: BoxFit.cover),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              margin: EdgeInsets.fromLTRB(0, 15, 0, 0),
              width: 250,
              height: 70,
              color: Colors.white,
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Text(
                  'Please Rate Us!',
                  style: TextStyle(
                    fontSize: 25,
                    fontFamily: 'Lora',
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ),

            Rating((rating) {
              setState(() {
                _rating = rating;
              });
            }, 5),
            Container(
              width: 250,
              height: 40,
              color: Colors.white,
              child: SizedBox(
                  height: 44,
                  child: (_rating != null && _rating != 0)
                      ? Text(
                          "You selected $_rating rating",
                          style: TextStyle(
                            fontSize: 18,
                          ),
                          textAlign: TextAlign.center,
                        )
                      : SizedBox.shrink()),
            ),
            Container(
              width: 250,
              height: 80,
              color: Colors.white,
              child: Text(
                _value,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: 'Lora',
                ),
              ),
            ),
            RaisedButton(
              onPressed: () => _askUser(),
              child: new Text('Rate?'),
            ),
            //Text('Hello')
            Center(
                child: Container(
              margin: EdgeInsets.fromLTRB(0, 30, 0, 0),
              width: 80,
              height: 30,
              color: Colors.white,
              child: RaisedButton(
                color: Colors.blue,
                child: Text(
                  'Back',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.white,
                  ),
                ),
                onPressed: () {
                  Navigator.pop(context);
                },
              ),
            )),
          ],
        ),
      ),
    )));
  }
}
