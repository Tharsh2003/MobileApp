import 'package:flutter/material.dart';
import 'package:simple_drawer/profilepage.dart';
import 'Register3.dart';

class HomePage2 extends StatefulWidget {
  final String id;
  final String password;
  final String email;
  final String phone;

  HomePage2(this.id, this.password, this.email, this.phone);
  @override
  State<StatefulWidget> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage2> {
  Color color = Colors.blueAccent;
  final controllerPwd = TextEditingController();
  final controllerId = TextEditingController();

  @override
  Widget build(BuildContext context) {
    String textId;
    String pic;
    String chpwd = controllerPwd.text;
    String chid = controllerId.text;
    String phone;
    String email;

    if (widget.id == 'superhero') {
      textId = widget.id;
      pic = "images/superhero.jpg";
    } else {
      textId = widget.id;
      phone = widget.phone;
      email = widget.email;
      pic = 'images/guest.png';
    }

    return MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
          //appBar: AppBar(title: Text('Login')),

          body: Center(
            child: Container(
              height: 603,
              width: 600.0,
              decoration: BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage("images/Register.jpg"),
                      fit: BoxFit.cover)),
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Container(
                      width: 380,
                      height: 50,
                      margin: EdgeInsets.fromLTRB(0, 20, 0, 0),
                      child: Center(
                        child: Text(
                          'Welcome ' + email,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 32,
                          ),
                        ),
                      ),
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            width: 3,
                          )),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(18.0),
                      child: TextField(
                        controller: controllerPwd,
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: Colors.white,
                          hintText: 'Email',
                          hintStyle: TextStyle(
                              fontWeight: FontWeight.w300, color: Colors.blue),
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.orange),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.orange),
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.all(18.0),
                        child: TextField(
                          controller: controllerId,
                          obscureText: true,
                          decoration: InputDecoration(
                            fillColor: Colors.white,
                            filled: true,
                            hintText: 'PWD',
                            hintStyle: TextStyle(
                                fontWeight: FontWeight.w300,
                                color: Colors.blue),
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.blue),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.orange),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 10, 0, 10),
                      width: 140.0,
                      height: 40.0,
                      decoration: BoxDecoration(
                          color: color,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            width: 3,
                          )),
                      child: RaisedButton(
                        color: Colors.black,
                        child: Text(
                          'Not Registered?',
                          style: TextStyle(color: Colors.white),
                        ),
                        onPressed: () {
                          {
                            setState(() {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => Register(),
                                ),
                              );
                            });
                          }
                        },
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 10, 0, 10),
                      width: 140.0,
                      height: 40.0,
                      decoration: BoxDecoration(
                          color: color,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            width: 3,
                          )),
                      child: RaisedButton(
                        color: Colors.black,
                        child: Text(
                          'Login',
                          style: TextStyle(color: Colors.white),
                        ),
                        onPressed: () {
                          if (widget.id == controllerPwd.text &&
                              widget.password == controllerId.text) {
                            setState(() {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => ProfilePage(
                                      controllerPwd.text,
                                      controllerId.text,
                                      email,
                                      phone),
                                ),
                              );
                            });
                          }
                        },
                      ),
                    ),
                  ]),
            ),
          ),
        ));
  }
}
