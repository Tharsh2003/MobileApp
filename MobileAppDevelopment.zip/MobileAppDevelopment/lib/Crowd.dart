import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'CartPage.dart';
import 'CartProvider.dart';
import 'Transport.dart';
//import 'Transport.dart';

//import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(CrowdPage());
}

class Crowd extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: CrowdPage(),
      ),
    );
  }
}

class CrowdPage extends StatefulWidget {
  final String image;
  final String price;
  final String description;
  final String rating;
  final String review;
  final String distance;

  const CrowdPage(
      {Key key,
      this.index,
      this.shoeName,
      this.image,
      this.price,
      this.description,
      this.rating,
      this.review,
      this.distance})
      : super(key: key);

  final int index;
  final String shoeName;

  _CrowdPageState createState() => _CrowdPageState();
}

class _CrowdPageState extends State<CrowdPage> {
  String selectedValue;
  //Always claim when there is dropdown menu

  int _itemCount = 0;
  Widget build(BuildContext context) {
    var cartProvider = Provider.of<CartProvider>(context);
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.shoeName),
        backgroundColor: Colors.lightBlueAccent,
        actions: <Widget>[
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Container(
              height: 150.0,
              width: 30.0,
              child: InkWell(
                  splashColor: Colors.redAccent,
                  highlightColor: Colors.blueAccent.withOpacity(0.5),
                  onTap: () {
                    cartProvider.setNameToCart(widget.index, widget.shoeName);
                    cartProvider.setDistanceToCart(
                        widget.index, widget.distance);
                    print(widget.distance);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => CartPage(),
                      ),
                    );
                  },
                  child: Stack(children: <Widget>[
                    IconButton(
                      icon: Icon(
                        Icons.shopping_cart,
                        color: Colors.white,
                      ),
                      onPressed: null,
                    ),
                    Positioned(
                        child: Stack(
                      children: <Widget>[
                        Icon(Icons.brightness_1,
                            size: 20.0, color: Colors.red[700]),
                        Positioned(
                          top: 3.0,
                          right: 7,
                          child: Center(
                            child: Text(
                              cartProvider.count.toString(),
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 12.0,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ),
                      ],
                    )),
                  ])),
            ),
          ),
        ],
      ),
      backgroundColor: Colors.lightBlueAccent[100],
      body: Container(
        child: Column(
          children: <Widget>[
            /*   Center(
              child: Container(
                margin: EdgeInsets.fromLTRB(0, 5, 0, 0),
                width: 350,
                height: 130,
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage('images/Time.jpg'),
                  ),
                ),
              ),
            ), */
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Column(mainAxisAlignment: MainAxisAlignment.center, children: <
                    Widget>[
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 5, 5, 0),
                    child: SizedBox(
                      width: 365,
                      height: 300,
                      child: Column(
                        //mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Padding(
                            padding: EdgeInsets.all(20),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                Column(
                                  children: <Widget>[
                                    Center(
                                      child: Padding(
                                        padding: EdgeInsets.all(5.0),
                                        child: Text(
                                          'Expected Waiting Time',
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 12,
                                            height: 1.0,
                                            color: Colors.white,
                                            fontFamily: 'Lora',
                                          ),
                                          textAlign: TextAlign.center,
                                        ),
                                      ),
                                    ),
                                    Center(
                                      child: Container(
                                        margin: EdgeInsets.fromLTRB(0, 5, 0, 0),
                                        width: 120,
                                        height: 80,
                                        decoration: BoxDecoration(
                                          image: DecorationImage(
                                            image:
                                                AssetImage('images/clock.png'),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Center(
                                      child: Padding(
                                        padding: EdgeInsets.all(5.0),
                                        child: Text(
                                          '1.5hrs',
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 12,
                                            height: 1.0,
                                            color: Colors.red,
                                            fontFamily: 'Lora',
                                          ),
                                          textAlign: TextAlign.center,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                Column(
                                  children: <Widget>[
                                    Center(
                                      child: Padding(
                                        padding: EdgeInsets.all(5.0),
                                        child: Text(
                                          'Number of Seats Available',
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 12,
                                            height: 1.0,
                                            color: Colors.white,
                                            fontFamily: 'Lora',
                                          ),
                                          textAlign: TextAlign.center,
                                        ),
                                      ),
                                    ),
                                    Center(
                                      child: Container(
                                        margin: EdgeInsets.fromLTRB(0, 5, 0, 0),
                                        width: 120,
                                        height: 80,
                                        decoration: BoxDecoration(
                                          image: DecorationImage(
                                            image:
                                                AssetImage('images/seat.png'),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Center(
                                      child: Padding(
                                        padding: EdgeInsets.all(5.0),
                                        child: Text(
                                          '3',
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 12,
                                            height: 1.0,
                                            color: Colors.red,
                                            fontFamily: 'Lora',
                                          ),
                                          textAlign: TextAlign.center,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          Column(
                            children: <Widget>[
                              Center(
                                child: Padding(
                                  padding: EdgeInsets.all(5.0),
                                  child: Text(
                                    'People infront of you',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 12,
                                      height: 1.0,
                                      color: Colors.white,
                                      fontFamily: 'Lora',
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                              ),
                              Center(
                                child: Container(
                                  margin: EdgeInsets.fromLTRB(0, 5, 0, 0),
                                  width: 120,
                                  height: 50,
                                  decoration: BoxDecoration(
                                    image: DecorationImage(
                                      image: AssetImage('images/people.png'),
                                    ),
                                  ),
                                ),
                              ),
                              Center(
                                child: Padding(
                                  padding: EdgeInsets.all(5.0),
                                  child: Text(
                                    '20',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 12,
                                      height: 1.0,
                                      color: Colors.red,
                                      fontFamily: 'Lora',
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    decoration: BoxDecoration(
                      color: Colors.blueAccent[100],
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ]),
              ],
            ),
            Container(
                child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      //Text("\$" + cartProvider.totalPrice.toString()),
                      IconButton(
                          icon: Icon(Icons.add),
                          onPressed: () {
                            cartProvider.addToCart(widget.index);
                            setState(() {
                              _itemCount++;
                              //cartProvider.setPriceToCart(widget.index);
                            });
                          })
                    ]),
                Text(_itemCount.toString()),
                IconButton(
                    icon: Icon(Icons.remove),
                    onPressed: () {
                      if (_itemCount <= 0) {
                        _itemCount = 0;
                      } else {
                        setState(
                          () {
                            _itemCount--;
                            cartProvider.removeFromCart(widget.index);
                          },
                        );
                      }
                    }),
                Center(
                    child: Container(
                  margin: EdgeInsets.fromLTRB(0, 30, 0, 0),
                  width: 280,
                  height: 40,
                  color: Colors.lightBlueAccent,
                  child: RaisedButton(
                    color: Colors.lightBlueAccent,
                    child: Text(
                      'View Crowd By Mode of Transport',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.white,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => Bicycle()),
                      );
                    },
                  ),
                )),
              ],
            )),
          ],
        ),
      ),
    );
  }
}
