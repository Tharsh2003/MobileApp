// To parse this JSON data, do
//
//     final welcome = welcomeFromJson(jsonString);

import 'dart:convert';

Welcome welcomeFromJson(String str) => Welcome.fromJson(json.decode(str));

String welcomeToJson(Welcome data) => json.encode(data.toJson());

class Welcome {
  Welcome({
    this.odataMetadata,
    this.value,
  });

  String odataMetadata;
  List<Value> value;

  factory Welcome.fromJson(Map<String, dynamic> json) => Welcome(
        odataMetadata: json["odata.metadata"],
        value: List<Value>.from(json["value"].map((x) => Value.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "odata.metadata": odataMetadata,
        "value": List<dynamic>.from(value.map((x) => x.toJson())),
      };
}

class Value {
  Value({
    this.description,
    this.latitude,
    this.longitude,
    this.rackType,
    this.rackCount,
    this.shelterIndicator,
  });

  String description;
  double latitude;
  double longitude;
  RackType rackType;
  int rackCount;
  ShelterIndicator shelterIndicator;

  factory Value.fromJson(Map<String, dynamic> json) => Value(
        description: json["Description"],
        latitude: json["Latitude"].toDouble(),
        longitude: json["Longitude"].toDouble(),
        rackType: rackTypeValues.map[json["RackType"]],
        rackCount: json["RackCount"],
        shelterIndicator: shelterIndicatorValues.map[json["ShelterIndicator"]],
      );

  Map<String, dynamic> toJson() => {
        "Description": description,
        "Latitude": latitude,
        "Longitude": longitude,
        "RackType": rackTypeValues.reverse[rackType],
        "RackCount": rackCount,
        "ShelterIndicator": shelterIndicatorValues.reverse[shelterIndicator],
      };
}

enum RackType { YELLOW_BOX, MRT_RACKS }

final rackTypeValues = EnumValues(
    {"MRT_RACKS": RackType.MRT_RACKS, "Yellow Box": RackType.YELLOW_BOX});

enum ShelterIndicator { N }

final shelterIndicatorValues = EnumValues({"N": ShelterIndicator.N});

class EnumValues<T> {
  Map<String, T> map;
  Map<T, String> reverseMap;

  EnumValues(this.map);

  Map<T, String> get reverse {
    if (reverseMap == null) {
      reverseMap = map.map((k, v) => new MapEntry(v, k));
    }
    return reverseMap;
  }
}
