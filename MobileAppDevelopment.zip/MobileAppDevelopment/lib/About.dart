import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter_email_sender/flutter_email_sender.dart';

class About extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: Colors.lightBlueAccent[100],
        body: MyAbout(),
      ),
    );
  }
}

class MyAbout extends StatefulWidget {
  MyAbout({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyAboutState createState() => _MyAboutState();
}

class _MyAboutState extends State<MyAbout> {
  final _itemImage = [
    Image.asset("images/Company.jpg"),
    Image.asset("images/Company2.jpg"),
    Image.asset("images/Company3.jpg"),
  ];

  int index = 0;

  tmpFunction() {
    Container(
      child: _itemImage[index],
      width: 500,
    );
  }

  Widget build(BuildContext) {
    return Container(
      height: 603,
      width: 600.0,
      decoration: BoxDecoration(
          image: DecorationImage(
              image: AssetImage("images/Register.jpg"), fit: BoxFit.cover)),
      child: Column(
        children: <Widget>[
          Center(
            child: Container(
              margin: EdgeInsets.fromLTRB(0, 25, 0, 20),
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('images/girl.jpg'),
                ),
                shape: BoxShape.circle,
              ),
            ),
          ),
          Container(
            child: Padding(
              padding: EdgeInsets.all(5),
              child: SizedBox(
                width: 350,
                child: Text(
                  'Hi,My name is Tharshini.\n\nDeveloper of food Bridge',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    height: 1.0,
                    fontFamily: 'Lora',
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 10, 5, 0),
                      child: SizedBox(
                        width: 365,
                        height: 290,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Container(
                                    child: _itemImage[index],
                                    width: 280,
                                    height: 130,
                                  ),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      FlatButton(
                                          onPressed: () {
                                            setState(() {
                                              index = 0;
                                            });
                                          },
                                          child: Text("•")),
                                      FlatButton(
                                          onPressed: () {
                                            setState(() {
                                              index = 1;
                                            });
                                          },
                                          child: Text("•")),
                                      FlatButton(
                                          onPressed: () {
                                            setState(() {
                                              index = 2;
                                            });
                                          },
                                          child: Text("•")),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            Center(
                              child: Padding(
                                padding: EdgeInsets.all(10.0),
                                child: Text(
                                  '\n Our Company\n\nAddress: Ang Mo Kio Ave 3 567433',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 12,
                                    height: 1.0,
                                    color: Colors.white,
                                    fontFamily: 'Lora',
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      decoration: BoxDecoration(
                        color: Colors.blueAccent[100],
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ]),
            ],
          ),
          ElevatedButton(
              onPressed: () => launch("tel://98538499"),
              child: new Text("Call me", textAlign: TextAlign.center)),
          ElevatedButton(
            onPressed: () async {
              /* launch(
                  'mailto:Tharshini@gmail.com?subject=This is Subject Title&body=This is Body of Email'); */
              final Email send_email = Email(
                body: 'body of email',
                subject: 'subject of email',
                recipients: ['Tharshini@gmail.com'],
                
              );

              await FlutterEmailSender.send(send_email);
            },
            child: Text("Email Us", style: TextStyle(fontFamily: 'Lora')),
          ),
        ],
      ),
    );
  }
}
