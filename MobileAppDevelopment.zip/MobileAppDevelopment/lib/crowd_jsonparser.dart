import 'dart:async';
import 'main.dart';
import 'package:flutter/material.dart';
import 'httpservice4.dart';
import 'Crowd2.dart';

class CPJsonParse4 extends StatefulWidget {
  CPJsonParse4({Key key}) : super(key: key);
  @override
  _CPJsonParseState createState() => _CPJsonParseState();
}

class Debouncer {
  final int msecond;
  VoidCallback action;
  Timer _timer;
  Debouncer({this.msecond});
  run(VoidCallback action) {
    if (null != _timer) {
      _timer.cancel();
    }
    _timer = Timer(Duration(milliseconds: msecond), action);
  }
}

String Level;

class _CPJsonParseState extends State<CPJsonParse4> {
  // List<Value> _user;

  final TextEditingController stationController = TextEditingController();

  final debouncer = Debouncer(msecond: 1000);

  List<Value> _cp;
  bool _loading;
  @override
  void initState() {
    super.initState();
    _loading = true;
    HttpService4.createBicycle(stationController.text).then((cp) {
      setState(() {
        _cp = cp;
        _loading = false;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_loading ? 'MRT Train Services' : 'Crowd Density'),
      ),
      body: Container(
        padding: EdgeInsets.all(8.0),
        child: Column(
          children: [
            Container(
              height: 120.0,
              width: 120.0,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('images/mrt_logo.jpg'),
                  fit: BoxFit.fill,
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.fromLTRB(20, 20, 20, 20),
              child: Container(
                  width: 280,
                  height: 40,
                  color: Colors.white,
                  child: RaisedButton(
                    color: Colors.black,
                    child: Text(
                      'Wish to take another transport to the restaurant?Click Me!',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.white,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    onPressed: () {
                     Navigator.pop(context, true);
                    },
                  )),
            ),
            Container(
              padding: EdgeInsets.all(32),
              child: Column(
                children: <Widget>[
                  Text(
                    'CCL,CEL,CGL,DTL,EWL,NEL,NSL,BPL,SLRT,PLRT',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.red,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Lora',
                    ),
                  ),
                  TextField(
                    controller: stationController,
                  ),
                  ElevatedButton(
                    onPressed: () async {
                      final String station = stationController.text;

                      final List<Value> stationName =
                          await HttpService4.createBicycle(station);

                      setState(() {
                        //_user = user;
                        debouncer.run(() {
                          HttpService4.createBicycle(station).then((uCp) {
                            setState(() {
                              _cp = stationName;
                            });
                          });
                        });
                      });
                    },
                    child: Text("Search"),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: null == _cp ? 0 : _cp.length,
                itemBuilder: (context, index) {
                  Value cpAvail = _cp[index];

                  return Card(
                      child: Padding(
                    padding: EdgeInsets.all(10.0),
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Station Name: ' +
                                    cpAvail.station.toString().split('.').last,
                                style: TextStyle(
                                    fontSize: 16.0, color: Colors.black),
                              ),
                              SizedBox(height: 5.0),
                              Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    'Crowd Level: ' +
                                        cpAvail.crowdLevel
                                            .toString()
                                            .split('.')
                                            .last,
                                    style: TextStyle(
                                        fontSize: 14.0, color: Colors.black87),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          Icon(Icons.directions, size: 50, color: Colors.red)
                        ]),
                  ));
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
