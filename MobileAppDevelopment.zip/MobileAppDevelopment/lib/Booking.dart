import 'package:flutter/material.dart';
import 'widgets/rating.dart';
import 'RateUs.dart';

void main() {
  runApp(BookingPage());
}

class Booking extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: BookingPage(),
      ),
    );
  }
}

class BookingPage extends StatefulWidget {
  final String distance;
  final int seat;

  const BookingPage({Key key, this.distance, this.seat});

  _BookingPageState createState() => _BookingPageState();
}

class _BookingPageState extends State<BookingPage> {
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
            child: Column(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: <Widget>[
          Container(
            width: 250,
            height: 40,
            margin: const EdgeInsets.fromLTRB(0, 10, 0, 0),
            decoration: BoxDecoration(
              //borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: Colors.black,
              ),
              color: Colors.lightBlueAccent,
            ),
            child: const Center(
              child: Text(
                'BOOKING',
                textAlign: TextAlign.center,
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
              ),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: <Widget>[
              Container(
                child: Column(
                  children: [
                    Container(
                      margin: const EdgeInsets.fromLTRB(0, 0, 5, 5),
                      width: 290,
                      height: 270,
                      decoration: BoxDecoration(
                        //borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: Colors.black,
                          width: 3,
                        ),
                        image: DecorationImage(
                          image: AssetImage('images/chin1.jpg'),
                          fit: BoxFit.cover,
                        ),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: <Widget>[
                          //color: Colors.white,
                          Center(
                            child: Container(
                              width: 130,
                              height: 50,
                              decoration: BoxDecoration(
                                  color: Colors.white70,
                                  //borderRadius: BorderRadius.circular(10),
                                  border: Border.all(
                                    color: Colors.black,
                                    width: 3,
                                  )),
                              child: Center(
                                child: Padding(
                                  padding: EdgeInsets.all(10),
                                  child: Text(
                                    'Ichiban',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        height: 1.5,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          Container(
            width: 150,
            height: 50,
            margin: const EdgeInsets.fromLTRB(0, 5, 0, 5),
            child: const Center(
              child: Text(
                'DISTANCE',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 28,
                  color: Colors.red,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Lora',
                ),
              ),
            ),
          ),
          Text(widget.distance),
          Container(
            width: 190,
            height: 30,
            margin: const EdgeInsets.fromLTRB(0, 10, 0, 5),
            child: const Center(
              child: Text(
                'QUEUE NO',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 28,
                  color: Colors.black,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Lora',
                ),
              ),
            ),
          ),
          Text((widget.seat + 1).toString()),
        ])));
  }
}
