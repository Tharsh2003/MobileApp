import 'package:flutter/material.dart';
import 'detailpage.dart';

class ProductPage extends StatelessWidget {
  final _shoeName = [
    'Iciban',
    'Ajsen Ramen',
    'Suparakki Ramen',
    'Jap Grill',
    'Sushi Tei',
    'Genki',
  ];

  final _shoePrice = [
    '35.0',
    '16.0',
    '30.0',
    '18.0',
    '32.0',
    '39.0',
  ];

  final _description = [
    'Ichiban specializes in premier Japanese cuisine without the hefty price tag. Dine at the sushi bar for the full experience.',
    'Famous for its rich Tonkotsu soup (pork broth) which captures the essence after hours of boiling, Ajisen offers a wide variety of ramen which caters to customers of all ages.',
    'Suparakki aims to create a ramen culture with an affordable price that would satisfy cravings and we will continue to strive for the better.',
    'At jap Grill we ensure that we serve meat of the finest quality',
    'At jap Grill we ensure that we serve meat of the finest quality',
    'At jap Grill we ensure that we serve meat of the finest quality',
  ];

  final _rating = [
    '3',
    '5',
    '4',
    '5'
        '3'
  ];

  final _review = [
    '34',
    '53',
    '46',
    '58'
        '31'
  ];

  final _distance = [
    '34km',
    '53km',
    '46km',
    '58km'
        '31km'
  ];

  Widget build(BuildContext context) {
    return Scaffold(
      body: GridView.count(
        crossAxisCount: 2,
        children: List.generate(
          6,
          (index) => InkWell(
              child: Card(
            color: Colors.white,
            elevation: 5,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(2.0),
                    child: Container(
                      height: 140,
                      width: 150,
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage('images/chin${index + 1}.jpg'),
                          fit: BoxFit.fitWidth,
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                  Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(_shoeName[index],
                            style: TextStyle(
                              fontSize: 12.0,
                              fontWeight: FontWeight.w500,
                            )),
                        IconButton(
                            icon: const Icon(Icons.add),
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => DetailPage(
                                    index: index,
                                    shoeName: _shoeName[index],
                                    image: 'images/chin${index + 1}.jpg',
                                    description: _description[index],
                                    rating: _rating[index],
                                    review: _review[index],
                                    distance: _distance[index],
                                    price: (_shoePrice[index]),
                                  ),
                                ),
                              );
                            }),
                      ]),
                ]),
          )),
        ),
      ),
    );
  }
}
