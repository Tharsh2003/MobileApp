import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'About.dart';
//import 'BMI.dart';
import 'CartProvider.dart';
import 'charts.dart';
import 'drawer.dart';
import 'Viewall.dart';
import 'googleMaps.dart';
import 'BestFood.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (context) => CartProvider(),
      child: MyApp(),
    ),
  );
}

class MyApp extends StatefulWidget {
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  String title = 'Home';
  int index = 0;
  List<Widget> list = [
    About(),
    BestFood(),
    GoogleMapScreen(),
    ChartPage(),
    //BMICalculator(),
    Viewall(),
  ];

  static String password;

  static String get id => null;

  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: Text(title),
        ),
        body: list[index],
        drawer: MyDrawer(onTap: (context, i, txt) {
          setState(() {
            index = i;
            title = txt;
            Navigator.pop(context);
          });
        }),
      ),
    );
  }
}
