import 'package:flutter/material.dart';
import 'package:simple_drawer/user/user_data.dart';
import 'package:simple_drawer/widgets/appbar_widget.dart';

class EditEmailFormPage extends StatefulWidget {
  const EditEmailFormPage({Key key}) : super(key: key);

  @override
  EditEmailFormPageState createState() {
    return EditEmailFormPageState();
  }
}

class EditEmailFormPageState extends State<EditEmailFormPage> {
  final _formKey = GlobalKey<FormState>();
  final emailController = TextEditingController();
  var user = UserData.myUser;

  @override
  void dispose() {
    emailController.dispose();
    super.dispose();
  }

  void updateUserValue(String email) {
    user.email = email;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: buildAppBar(context),
        body: Container(
          height: 603,
          width: 600.0,
          decoration: BoxDecoration(
              image: DecorationImage(
                  image: AssetImage("images/Register.jpg"), fit: BoxFit.cover)),
          child: Form(
            key: _formKey,
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Center(
                    child: Container(
                        color: Colors.white,
                        width: 320,
                        height: 50,
                        margin: EdgeInsets.fromLTRB(0, 40, 0, 0),
                        child: SizedBox(
                          width: 320,
                          child: Center(
                            child: const Text(
                              "What's your email?",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 25,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Lora',
                              ),
                            ),
                          ),
                        )),
                  ),
                  Padding(
                      padding: EdgeInsets.only(top: 40),
                      child: SizedBox(
                          height: 250,
                          width: 320,
                          child: TextFormField(
                            // Handles Form Validation
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please enter your email.';
                              }
                              return null;
                            },
                            decoration: const InputDecoration(
                                fillColor: Colors.white,
                                filled: true,
                                labelText: 'Your email address'),
                            controller: emailController,
                          ))),
                  Padding(
                      padding: EdgeInsets.only(top: 150),
                      child: Align(
                          alignment: Alignment.bottomCenter,
                          child: SizedBox(
                            width: 320,
                            height: 50,
                            child: ElevatedButton(
                              onPressed: () {
                                updateUserValue(emailController.text);
                                Navigator.pop(context);
                              },
                              child: const Text(
                                'Update',
                                style: TextStyle(fontSize: 15),
                              ),
                            ),
                          )))
                ]),
          ),
        ));
  }
}
