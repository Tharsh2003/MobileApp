import 'dart:async';
import 'package:flutter/material.dart';
import 'package:simple_drawer/pages/edit_description.dart';
import 'package:simple_drawer/pages/edit_email.dart';
import '../user/user.dart';
import '../user/user_data.dart';
import 'package:flutter/cupertino.dart';

class ProfilePage extends StatefulWidget {
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  TextStyle _style = TextStyle(fontSize: 55);
  bool _isDark = false;
  ThemeData _light = ThemeData.light().copyWith(
    primaryColor: Colors.green,
  );
  ThemeData _dark = ThemeData.dark().copyWith(
    primaryColor: Colors.black,
  );

  Color color = Colors.black;
  void toggleColor() {
    setState(() {
      if (color == Colors.white) {
        color = Colors.black;
      } else {
        color = Colors.white;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final user = UserData.myUser;
    return MaterialApp(
        darkTheme: _dark,
        theme: _light,
        themeMode: _isDark ? ThemeMode.dark : ThemeMode.light,
        debugShowCheckedModeBanner: false,
        title: 'Flutter Theme',
        home: Scaffold(
            body: Container(
                height: 603,
                width: 600.0,
                child: Container(
                  child: Column(
                    children: [
                      AppBar(
                        backgroundColor: Colors.transparent,
                        elevation: 0,
                        toolbarHeight: 10,
                      ),
                      Center(
                          child: Padding(
                              padding: EdgeInsets.only(bottom: 10),
                              child: Text(
                                'Edit Profile',
                                style: TextStyle(
                                  fontSize: 40,
                                  fontWeight: FontWeight.w700,
                                  // color: Color.fromRGBO(64, 105, 225, 1),
                                  color: color,
                                  fontFamily: 'Lora',
                                ),
                              ))),
                      Padding(
                        padding: const EdgeInsets.only(top: 10),
                        child: CupertinoSwitch(
                          value: _isDark,
                          onChanged: (v) {
                            setState(() {
                              _isDark = !_isDark;
                              toggleColor();
                            });
                          },
                        ),
                      ),
                      Container(
                        width: 180,
                        margin: EdgeInsets.fromLTRB(0, 10, 0, 50),
                        child: Text(
                          'Toggle for light or dark mode',
                          textAlign: TextAlign.center,
                        ),
                      ),
                      Text(
                        'Username',
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          color: color,
                        ),
                      ),
                      Container(
                          width: 350,
                          height: 60,
                          decoration: BoxDecoration(
                              color: color,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                color: color,
                                width: 3,
                              )),
                          margin: EdgeInsets.fromLTRB(0, 10, 0, 10),
                          child: SizedBox(
                            width: 320,
                            child: Center(
                              child: const Text(
                                "Tharshini03",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 16,
                                  height: 1.4,
                                  color: Colors.blue,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          )),
                      Text(
                        'Phone Number',
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          color: color,
                        ),
                      ),
                      Container(
                          width: 350,
                          height: 60,
                          decoration: BoxDecoration(
                              color: color,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                color: color,
                                width: 3,
                              )),
                          margin: EdgeInsets.fromLTRB(0, 10, 0, 10),
                          child: SizedBox(
                            width: 320,
                            child: Center(
                              child: const Text(
                                "+65 98538499",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 16,
                                  height: 1.4,
                                  color: Colors.blue,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          )),
                      buildUserInfoDisplay(
                          user.email, 'Email', EditEmailFormPage()),
                      Expanded(
                        child: buildAbout(user),
                        flex: 4,
                      )
                    ],
                  ),
                ))));
  }

  Widget buildUserInfoDisplay(String getValue, String title, Widget editPage) =>
      Padding(
          padding: EdgeInsets.only(bottom: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Text(
                  title,
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                    color: color,
                  ),
                ),
              ),
              SizedBox(
                height: 1,
              ),
              Center(
                  child: Container(
                      width: 350,
                      height: 60,
                      decoration: BoxDecoration(
                          color: color,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            color: color,
                            width: 3,
                          )),
                      child: Row(children: [
                        Expanded(
                            child: TextButton(
                                onPressed: () {
                                  navigateSecondPage(editPage);
                                },
                                child: Text(
                                  getValue,
                                  style: TextStyle(
                                    fontSize: 16,
                                    height: 1.4,
                                    color: Colors.lightBlueAccent[50],
                                  ),
                                ))),
                      ])))
            ],
          ));

  Widget buildAbout(User user) => Padding(
      padding: EdgeInsets.only(bottom: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Text(
              'Tell Us About Yourself',
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
          ),
          const SizedBox(height: 1),
          Center(
              child: Container(
                  width: 350,
                  height: 65,
                  decoration: BoxDecoration(
                      color: color,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: color,
                        width: 3,
                      )),
                  child: Row(children: [
                    Expanded(
                        child: TextButton(
                            onPressed: () {
                              navigateSecondPage(EditDescriptionFormPage());
                            },
                            child: Padding(
                                padding: EdgeInsets.fromLTRB(0, 5, 10, 5),
                                child: Align(
                                    alignment: Alignment.topLeft,
                                    child: Text(
                                      user.aboutMeDescription,
                                      style: TextStyle(
                                        fontSize: 16,
                                        height: 1.4,
                                        color: Colors.blueAccent[50],
                                      ),
                                    ))))),
                  ]))),
        ],
      ));

  FutureOr onGoBack(dynamic value) {
    setState(() {});
  }

  void navigateSecondPage(Widget editForm) {
    Route route = MaterialPageRoute(builder: (context) => editForm);
    Navigator.push(context, route).then(onGoBack);
  }
}
