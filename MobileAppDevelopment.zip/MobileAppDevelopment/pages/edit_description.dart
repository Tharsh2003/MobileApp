import 'package:flutter/material.dart';
import 'package:simple_drawer/user/user_data.dart';
import 'package:simple_drawer/widgets/appbar_widget.dart';

class EditDescriptionFormPage extends StatefulWidget {
  @override
  _EditDescriptionFormPageState createState() =>
      _EditDescriptionFormPageState();
}

class _EditDescriptionFormPageState extends State<EditDescriptionFormPage> {
  final _formKey = GlobalKey<FormState>();
  final descriptionController = TextEditingController();
  var user = UserData.myUser;

  @override
  void dispose() {
    descriptionController.dispose();
    super.dispose();
  }

  void updateUserValue(String description) {
    user.aboutMeDescription = description;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: buildAppBar(context),
        body: Container(
            height: 603,
            width: 600.0,
            decoration: BoxDecoration(
                image: DecorationImage(
                    image: AssetImage("images/Register.jpg"),
                    fit: BoxFit.cover)),
            child: Form(
              key: _formKey,
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Center(
                      child: Container(
                        color: Colors.white,
                        width: 350,
                        height: 50,
                        margin: EdgeInsets.fromLTRB(0, 40, 0, 0),
                        child: SizedBox(
                            width: 350,
                            child: Center(
                                child: const Text(
                              "Describe Yourself",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 25,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Lora',
                              ),
                            ))),
                      ),
                    ),
                    Padding(
                        padding: EdgeInsets.all(20),
                        child: SizedBox(
                            height: 250,
                            width: 350,
                            child: TextFormField(
                              validator: (value) {
                                if (value == null ||
                                    value.isEmpty ||
                                    value.length > 200) {
                                  return 'Please describe yourself but keep it under 200 characters.';
                                }
                                return null;
                              },
                              controller: descriptionController,
                              textAlignVertical: TextAlignVertical.top,
                              decoration: const InputDecoration(
                                  fillColor: Colors.white,
                                  filled: true,
                                  alignLabelWithHint: true,
                                  contentPadding:
                                      EdgeInsets.fromLTRB(10, 15, 10, 60),
                                  hintMaxLines: 3,
                                  hintText:
                                      'Write a little bit about yourself. Do you like chatting?Do you bring pets with you? Etc.'),
                            ))),
                    Padding(
                        padding: EdgeInsets.only(top: 10),
                        child: Align(
                            alignment: Alignment.bottomCenter,
                            child: SizedBox(
                              width: 350,
                              height: 50,
                              child: ElevatedButton(
                                onPressed: () {
                                  updateUserValue(descriptionController.text);
                                  Navigator.pop(context);
                                },
                                child: const Text(
                                  'Update',
                                  style: TextStyle(fontSize: 15),
                                ),
                              ),
                            )))
                  ]),
            )));
  }
}
